﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace supermarket
{
    public interface ProductOperations
    {
        void AddProduct();
        void DeleteProduct();
        void DisplayProduct();
    }

   


    
}
